style: jungle
--------------
Sunset in the jungle, trees do not let to see the last rays of sun on the horizon, small creek in the path, mug on the shoes, a touch of danger and the adventure feeling, get into your jeep and drive with this style.  

![jungle style table](style_table.png)

screenshot
-----------

![jungle style screen](screenshot.png)

about font
-----------
"Pixel Intv" font by [Pixel Sagas](http://www.pixelsagas.com) (Neale and Shayna Davidson).

100% free font, downloaded from dafont.com: [pixel-intv](https://www.dafont.com/pixel-intv.font)
