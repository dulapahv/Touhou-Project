style: candy
-------------
Sweet, colorful, tasty! Enjoy this funfair ride and be careful with the witch of the candy house!

![candy style table](style_table.png)

screenshot
-----------

![candy style screen](screenshot.png)

about font
-----------
"V5 Eastergothic" font by vFive Digital (Roberto Christen).

100% free font, downloaded from dafont.com: [v5eastergothic](https://www.dafont.com/v5eastergothic.font)
